// ==========================================
// GYM POLE MONITOR - ESP32
// ==========================================

// ---------- PINOS ----------

const int TRIG_PIN = 5;
const int ECHO_PIN = 18;

const int RED_LED_PIN = 19;

const int RGB_GREEN_PIN = 21;
const int RGB_BLUE_PIN = 22;

const int BUTTON_PIN = 23;


// ---------- CONFIGURAÇÕES ----------

// Tempo necessário detectando alguém
// para confirmar que a estação está ocupada.
const unsigned long OCCUPATION_CONFIRM_TIME = 2000;

// Tempo sem detectar alguém
// para confirmar que a estação está disponível.
const unsigned long RELEASE_CONFIRM_TIME = 5000;


// Distância máxima considerada como pessoa.
// Ajustaremos depois se necessário.
const float DETECTION_DISTANCE = 100.0;


// ---------- ESTADOS ----------

bool maintenanceMode = false;
bool occupied = false;


// ---------- CONTADORES ----------

unsigned long detectionStartTime = 0;
unsigned long absenceStartTime = 0;


// ---------- BOTÃO ----------

bool lastButtonState = LOW;


// ==========================================
// SETUP
// ==========================================

void setup() {

  Serial.begin(115200);

  // Sensor
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // LEDs
  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(RGB_GREEN_PIN, OUTPUT);
  pinMode(RGB_BLUE_PIN, OUTPUT);

  // Botão
  pinMode(BUTTON_PIN, INPUT);

  // Estado inicial
  setAvailable();

  Serial.println();
  Serial.println("================================");
  Serial.println("GYM POLE MONITOR");
  Serial.println("ESP32 iniciado");
  Serial.println("================================");
}


// ==========================================
// LOOP
// ==========================================

void loop() {

  // ========================================
  // BOTÃO DE MANUTENÇÃO
  // ========================================

  bool buttonState = digitalRead(BUTTON_PIN);

  // Detecta somente quando o botão
  // passa de SOLTO para PRESSIONADO.
  if (buttonState == HIGH && lastButtonState == LOW) {

    maintenanceMode = !maintenanceMode;

    if (maintenanceMode) {

      Serial.println(">>> MANUTENCAO ATIVADA");

      setMaintenance();

    } else {

      Serial.println(">>> MANUTENCAO DESATIVADA");

      // Ao sair da manutenção,
      // volta para o estado determinado
      // pelo sensor.

      if (occupied) {
        setOccupied();
      } else {
        setAvailable();
      }
    }

    // Pequeno debounce
    delay(100);
  }

  lastButtonState = buttonState;


  // ========================================
  // MANUTENÇÃO TEM PRIORIDADE
  // ========================================

  if (maintenanceMode) {

    setMaintenance();

    delay(100);

    return;
  }


  // ========================================
  // LEITURA DO SENSOR
  // ========================================

  float distance = readDistance();

  Serial.print("Distancia: ");
  Serial.print(distance);
  Serial.println(" cm");


  // ========================================
  // VERIFICAÇÃO DE DETECÇÃO
  // ========================================

  bool personDetected = false;

  if (distance > 0 && distance <= DETECTION_DISTANCE) {
    personDetected = true;
  }


  // ========================================
  // PESSOA DETECTADA
  // ========================================

  if (personDetected) {

    // Começou uma nova detecção
    if (detectionStartTime == 0) {

      detectionStartTime = millis();

      Serial.println("Detectando pessoa...");
    }

    // Como existe alguém,
    // cancelamos o contador de ausência.
    absenceStartTime = 0;


    // Confirma ocupação somente depois
    // de 2 segundos de detecção contínua.
    if (!occupied &&
        millis() - detectionStartTime >= OCCUPATION_CONFIRM_TIME) {

      occupied = true;

      Serial.println(">>> ESTACAO OCUPADA");

      setOccupied();
    }

  }


  // ========================================
  // NINGUÉM DETECTADO
  // ========================================

  else {

    // Cancela o contador de detecção.
    detectionStartTime = 0;


    if (occupied) {

      // Começou o período sem detecção.
      if (absenceStartTime == 0) {

        absenceStartTime = millis();

        Serial.println(
          "Pessoa saiu? Aguardando confirmacao..."
        );
      }


      // Só libera depois de 5 segundos.
      if (millis() - absenceStartTime >= RELEASE_CONFIRM_TIME) {

        occupied = false;

        absenceStartTime = 0;

        Serial.println(">>> ESTACAO DISPONIVEL");

        setAvailable();
      }

    } else {

      // Se nunca esteve ocupada,
      // permanece disponível.
      setAvailable();
    }
  }


  delay(100);
}


// ==========================================
// LEITURA DO HC-SR04
// ==========================================

float readDistance() {

  // Garante que o TRIG começa desligado.
  digitalWrite(TRIG_PIN, LOW);

  delayMicroseconds(2);


  // Envia pulso de 10 microssegundos.
  digitalWrite(TRIG_PIN, HIGH);

  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);


  // Aguarda o retorno do ECHO.
  long duration = pulseIn(
    ECHO_PIN,
    HIGH,
    30000
  );


  // Nenhum retorno recebido.
  if (duration == 0) {
    return -1;
  }


  // Converte tempo para centímetros.
  float distance = duration * 0.0343 / 2;

  return distance;
}


// ==========================================
// LED: DISPONÍVEL
// ==========================================

void setAvailable() {

  // Vermelho OFF
  digitalWrite(RED_LED_PIN, LOW);

  // Verde ON
  digitalWrite(RGB_GREEN_PIN, HIGH);

  // Azul OFF
  digitalWrite(RGB_BLUE_PIN, LOW);
}


// ==========================================
// LED: OCUPADA
// ==========================================

void setOccupied() {

  // Vermelho ON
  digitalWrite(RED_LED_PIN, HIGH);

  // Verde OFF
  digitalWrite(RGB_GREEN_PIN, LOW);

  // Azul OFF
  digitalWrite(RGB_BLUE_PIN, LOW);
}


// ==========================================
// LED: MANUTENÇÃO
// ==========================================

void setMaintenance() {

  // Vermelho OFF
  digitalWrite(RED_LED_PIN, LOW);

  // Verde OFF
  digitalWrite(RGB_GREEN_PIN, LOW);

  // Azul ON
  digitalWrite(RGB_BLUE_PIN, HIGH);
}