const int TRIG = 5;
const int ECHO = 18;
const int BOTAO = 4;
const int LED_VERMELHO = 25;
const int RGB_VERDE = 26;
const int RGB_AZUL = 27;

const int DISTANCIA_MAX = 50;   // cm: abaixo disso, há pessoa
bool pessoaEstava = false;
bool mostrandoVerde = false;

long medirDistancia() {
  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long duracao = pulseIn(ECHO, HIGH, 30000);   // timeout 30 ms
  if (duracao == 0) return 999;                // sem eco = nada perto
  return duracao * 0.034 / 2;
}

void setup() {
  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);
  pinMode(BOTAO, INPUT);                       // pull-down externo
  pinMode(LED_VERMELHO, OUTPUT);
  pinMode(RGB_VERDE, OUTPUT);
  pinMode(RGB_AZUL, OUTPUT);
}

void loop() {
  bool pessoa = medirDistancia() < DISTANCIA_MAX;
  bool botao = digitalRead(BOTAO) == HIGH;

  if (pessoa) {
    mostrandoVerde = false;
  } else if (pessoaEstava) {                   // acabou de sair
    mostrandoVerde = true;
  }
  pessoaEstava = pessoa;

  digitalWrite(LED_VERMELHO, pessoa && !botao);
  digitalWrite(RGB_VERDE, mostrandoVerde && !botao);
  digitalWrite(RGB_AZUL, botao);               // botão tem prioridade

  delay(60);
}
